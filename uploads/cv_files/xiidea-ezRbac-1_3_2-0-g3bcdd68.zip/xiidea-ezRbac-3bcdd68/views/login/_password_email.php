<body>
<div align="center">
    <table border="0" width="700px" cellspacing="0" cellpadding="2" style="font-family: Arial; font-size: 8pt">
        <tr>
            <td bgcolor="#333333" align="center">
                <table border="0" width="698px" style="border-collapse: collapse; font-family: Arial; font-size:10pt"
                       cellpadding="0" bgcolor="#FFFFFF">
                    <tr>
                        <td height="10px" bgcolor="#000000">
                        </td>
                    </tr>
                    <tr>
                        <td height="10px" bgcolor="#555555">
                        </td>
                    </tr>
                    <tr>
                        <td height="10px" bgcolor="#999999">
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <table border="0" width="696px" cellspacing="0" cellpadding="6"
                                   style="font-family: Arial; font-size: 10pt">
                                <tr>
                                    <td>


                                        <div align="justify">
                                            <p>
                                                <?php echo "Dear <strong>user !</strong>" ?>
                                                <br><br>

                                                Our system received a request to reset the password for your account.
                                            </p>

                                            <p>If you want to reset your password, click on the link below (or copy and
                                                paste the URL into your browser):<br>
                                                <a href="<?php echo $url ?>"
                                                   target="_blank"><?php echo  $url ?></a></p>

                                            <p>If you don't want to reset your password, please ignore this message. The
                                                link willl become invalid after 2 days. Your password will not be reset.
                                                <br/><br/>
                                                If you have any concerns, please contact us. We are always
                                                happy to assist you !! Please let us know if you need any
                                                more assistance or help from us to manage your website.

                                                <br/><br/>
                                                with best regards !<br>
                                                <b>System Administrator<br>
                                                <br/>
                                                <br/>
                                                <font color="#333333">
                                                    <b>Confidentiality Information and Disclaimer:</b></font><br>
                                                <span style="color:#333333">This communication sent from our website  is confidential and intended solely for the use of addressee. Any retransmission, dissemination or the use of this information by persons other than addressee is prohibited. If you did not initiate this process, please feel free to disregard this message and delete it.</span>
                                            </p>
                                        </div>

                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td height="25" bgcolor="#333" align="center">
                            <font color="#FFFFFF">this is a system generated auto email.
                                please do not reply.
                            </font></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td align="right">
                this system is pwoered by <a style="text-decoration:none; font-weight:bold"
                                             href="http://www.xiidea.net">xiidea.net</a>
                &nbsp;&nbsp; </td>
        </tr>
    </table>
</div>
</body>